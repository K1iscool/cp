# Measurements program

#===============
# Menu VVVVVV
#===============

def menu():
  print('''1. Feet to Inches
2. Inches to Feet
3. Quit''')
  global menu_choice
  menu_choice = str(input("Enter Choice: "))
  if menu_choice == "1":
    menu_choice = "feet"
  elif menu_choice == "2":
    menu_choice = "inches"
  elif menu_choice > "3":
    print("Invalid input")
    menu()
  else:
    print("Goodbye")
    quit()
  ansr()

#===============
# Getting Answer
#===============

def ansr():
  try:
    global answer
    answer = float(input(f"Enter the number of {menu_choice}"))
  except ValueError:
    ansr()
  

#===============
# Feet To Inches
#===============

def fti():
  output = answer * 12
  print(f"{menu_choice} is {output} in inches")

#===============
# Feet To Inches
#===============

def itf():
  output = answer / 12
  print(f"{menu_choice} is {output} in feet")

#===============
# Main
#===============

menu()
if menu_choice == "feet":
  fti()
elif menu_choice == "inches":
  itf()
else:
  print("An unexpected error has occured")
  exit()
