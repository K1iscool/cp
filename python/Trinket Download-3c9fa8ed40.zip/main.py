# Adder program







# -------------------------
# Subprograms
# -------------------------
def adder():
    total = 0
    top = 0
    bottom = 0
    count = 0
    ave = 0
    complete = False
    while not complete:
        number = input("Enter number: ")
        if number == "e":
          complete = True
          if count > 0:
            ave = total /count
          else:
            ave = 0
        
        else:
          number = float(number)
          total = total + number
          count = count + 1
          if number > top:
            top = number
          else:
            if count == 1 or number < bottom:
              bottom = number
          
          
          
        
        
    print("Total:", total, "Top:", top, "Ave:", ave)


# -------------------------
# Main program
# -------------------------
adder()
