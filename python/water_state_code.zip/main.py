# States of water program

# -------------------------
# Subprograms
# -------------------------
def water_state(temperature):
    
    if temperature <= 0:
      return "Solid"
    
    elif temperature <= 100:
      return "liquid"
    
    else:
      return "gaseous"
    
  


# -------------------------
# Main program
# -------------------------

temperature = float(input("Input the temperature in centigrade"))
state = water_state(temperature)
print("The water is in a", state, "state.")
