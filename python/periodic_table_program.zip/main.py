# Periodic table program

# -------------------------
# Subprograms
# -------------------------

def periodic_table(element):
  if element == "Li" or element == "Lithium":
    return "Symbol: Li Element: Lithium Atomic weight: 6.94 Group: Alkali metals"
  elif element == "Na" or element == "Sodium":
    return "Symbol: Na Element: Sodium Atomic weight: 22.99 Group: Alkali metals"
  elif element == "K" or element == "Potassium":
    return "Symbol: K Element: Potasium Atomic weight: 39.098 Group: Alkali metals"
  elif element == "F" or element == "Fluorine":
    return "Symbol: F Element: Fluorine Atomic weight: 18.998 Group: Halogens"
  elif element == "Cl" or element == "Chlorine":
    return "Symbol: Cl Element: Chlorine Atomic weight: 35.45 Group: Halogens"
  elif element == "Br" or element == "Bromine":
    return "Symbol: Br Element: Bromine Atomic weight: 79.904 Group: Halogens"
  else:
    return "Element is not in the catalogue"

# -------------------------
# Main program
# -------------------------

element = input("Enter the symbol or name of an element: ")
print(periodic_table(element))
