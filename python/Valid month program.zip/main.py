# Valid month program

# -------------------------
# Subprograms
# -------------------------
def validate_month(month):
  month = int(input("Enter a month 1-12: "))
  if month > 0 and month < 13:
    return month
  else:
    return validate_month(month)


# -------------------------
# Main program
# -------------------------
month = 0
valid_month = validate_month(month)
print("Thank you. Input accepted.")
