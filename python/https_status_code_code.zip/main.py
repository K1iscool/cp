# HTTP status codes program

# -------------------------
# Subprograms
# -------------------------
def http_status(status):
  match code:
    case 400:
      return "bad request"
    
    case 401 | 403:
      return "authentication error"
      
    case 404:
      return "not found"
    
    case _:
      return "unknown error"

# -------------------------
# Main program
# -------------------------
code = int(input("Input error code: "))
print(http_status(code))
