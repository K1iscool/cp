# Exam grade program

# -------------------------
# Subprograms
# -------------------------

def grade():
  if mark >= 80:
    return "9"
  
  elif mark >= 67:
    return "8"
    
  elif mark >= 54:
    return "7"
    
  elif mark >= 41:
    return "6"
    
  elif mark >= 31:
    return "5"
    
  elif mark >= 22:
    return "4"
    
  elif mark >= 13:
    return "3"
    
  elif mark >= 4:
    return "2"
    
  elif mark >= 2:
    return "1"
    
  else:
    return "U"
    


# -------------------------
# Main program
# -------------------------

mark = int(input("Enter the mark"))